from typing import List

from fastapi import FastAPI
from pydantic import BaseModel

from model import Predictor

app = FastAPI()
predictor = Predictor()


class Message(BaseModel):
    message: str


class RecResponse(BaseModel):
    recs: List[str]


@app.get("/api/v1/health", response_model=Message)
async def health() -> Message:
    return Message(message="Success.")


@app.get("/api/v1/predict/", response_model=RecResponse)
async def predict(user: str, n_recs: int) -> RecResponse:
    return RecResponse(recs=predictor(user, n_recs))
