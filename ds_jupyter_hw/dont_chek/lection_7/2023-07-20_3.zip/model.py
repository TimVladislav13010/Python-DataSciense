import json


class Predictor:
    def __init__(self) -> None:
        with open("rec_data.json", "r") as file:
            self.data = json.load(file)

    def __call__(self, uid: str, k: int):
        
        return [x[0] for x in self.data[uid][:k]]